
/**
 * Código tomado y editado de: http://proyectosbeta.blogspot.com/
 */
import java.util.*;
import java.io.*; 
public class AVLTree {
    private AVLNode root;

    public void insert( Comparable x ){
        root = insert( x, root );
    }

    private AVLNode insert( Comparable x, AVLNode t ){
        if( t == null ){
            t = new AVLNode( x, null, null );
        }
        else if( x.compareTo( t.dato ) < 0 ) {
            t.izquierdo = insert( x, t.izquierdo );
            if( height( t.izquierdo ) - height( t.derecho ) == 2 ){
                if( x.compareTo( t.izquierdo.dato ) < 0 ){
                    t = rotateWithLeftChild( t );
                }
                else{
                    t = doubleWithLeftChild( t ); 
                }
            }
        }
        else if( x.compareTo( t.dato ) > 0 ) {
            t.derecho = insert( x, t.derecho );
            if( height( t.derecho ) - height( t.izquierdo ) == 2 ){
                if( x.compareTo( t.derecho.dato ) > 0 ){
                    t = rotateWithRightChild( t ); 
                }
                else{
                    t = doubleWithRightChild( t ); 
                }
            }
        }
        else{}
        t.height = max( height( t.izquierdo ), height( t.derecho ) ) + 1;
        return t;
    }
    
    public void search(Comparable val){
        if(!search(root,val)){
            System.out.println("El archivo " + val + " no existe");
        }
        else{
            System.out.println("El archivo " + val + " se ha encontrado");
        }
    }
    
    private boolean search(AVLNode nodo, Comparable val){
        boolean found = false;
        while(nodo != null && !found){
            if(val.compareTo(nodo.dato) < 0){
                nodo = nodo.izquierdo;
            }
            else if(val.compareTo(nodo.dato) > 0){
                nodo = nodo.derecho;
            }
            else{
                found = true;
                break;
            }
            found = search(nodo, val);
        }
        return found;
    }

    private static int max( int lhs, int rhs ){
        return lhs > rhs ? lhs : rhs;
    }

    private static AVLNode rotateWithLeftChild( AVLNode k2 ){
        AVLNode k1 = k2.izquierdo;
        k2.izquierdo = k1.derecho;
        k1.derecho = k2;
        k2.height = max( height( k2.izquierdo), height(k2.derecho)) + 1;
        k1.height = max( height( k1.izquierdo ), k2.height ) + 1;
        return k1;
    }

    private static AVLNode rotateWithRightChild( AVLNode k1 ){
        AVLNode k2 = k1.derecho;
        k1.derecho = k2.izquierdo;
        k2.izquierdo = k1;
        k1.height = max( height(k1.izquierdo), height(k1.derecho) ) + 1;
        k2.height = max( height( k2.derecho ), k1.height ) + 1;
        return k2;
    }

    private static AVLNode doubleWithLeftChild( AVLNode k3 ){
        k3.izquierdo = rotateWithRightChild( k3.izquierdo );
        return rotateWithLeftChild( k3 );
    }

    private static AVLNode doubleWithRightChild( AVLNode k1 ){
        k1.derecho = rotateWithLeftChild( k1.derecho );
        return rotateWithRightChild( k1 );
    }

    private static int height( AVLNode t ){
        return t == null ? -1 : t.height;
    }
    
    public void leerArchivo(String nombreArchivo) throws IOException{
        FileReader in = new FileReader(new File(nombreArchivo));
        BufferedReader br = new BufferedReader(in);
        String archivo;
        while((archivo = br.readLine()) != null){
            if(archivo.contains("]")){
                Comparable array[] = archivo.split("]  ");
                insert(array[1]);
            }
            else{
                insert(archivo);
            }
        }
    }
    
    public static void dibujarArbol(AVLTree a){
       System.out.println("http://www.webgraphviz.com/"); 
       dibujarArbolAux(a.root);
    }
    
    public static void dibujarArbolAux(AVLNode nodo){
      if (nodo != null)
         //"x_\n__" -> "xo\n__";
         for(AVLNode n: new AVLNode[] {nodo.izquierdo, nodo.derecho} ){
            if (n != null)
               System.out.println("\"" + nodo.dato + "\" -> \"" + n.dato + "\";");
            dibujarArbolAux(n);
        }
    }
}
