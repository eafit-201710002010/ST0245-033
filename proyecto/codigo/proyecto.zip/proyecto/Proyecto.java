import java.util.*;
import java.math.*;
import java.io.*;
import javax.swing.JOptionPane;

public class Proyecto
{    
    public Proyecto(){
        try{
            File proyecto = new File("Directorio.txt");
            if(!proyecto.exists()){
                BufferedWriter escribir = new BufferedWriter(new FileWriter(proyecto));
                escribir.write("Proyecto/");
                escribir.close();
            }
        }
        catch(Exception e){
            System.out.println("Ha ocurrido un error");
        }
    }    

    public void vaciar(){
        try{
            File proyecto = new File("Directorio.txt");
            if(proyecto.exists()){
                BufferedWriter buffer = new BufferedWriter(new FileWriter(proyecto));
                buffer.write("Proyecto/");
                buffer.close();
                System.out.println("Archivo vacío");
            }
            else{
                System.out.println("El archivo no existe");
            }
        }
        catch(IOException e){
            System.out.println("Ha ocurrido un error");
        }     
    }
    
    public void agregarDirectorio(String usuario, String tam, String directorio){
         try{
            File proyecto = new File("Directorio.txt");
            FileWriter escribir = new FileWriter(proyecto, true);
            BufferedWriter buffer = new BufferedWriter(escribir);
            buffer.newLine();
            buffer.write("|--["+usuario+" "+tam+"] "+directorio);           
            buffer.close();
        }
        catch(Exception e){
            System.out.println("Ha ocurrido un error");
        }
    }
    
    public void agregarFichero(String usuario, String tam, String directorio, String fichero){        
        try{
            Scanner input = new Scanner(new File("Directorio.txt"));
            ArrayList<String> datos = new ArrayList<String>();
            int cont = 0;
            boolean existe = false;
            while(input.hasNext()){
                String mod=input.nextLine();  
                datos.add(mod); 
                cont++;
                if(mod.contains(directorio)){
                    datos.add(cont, "|---------["+usuario+" "+tam+"] "+fichero);
                    existe = true;
                }               
            }
            PrintStream out = new PrintStream(new File("Directorio.txt"));
            File proyecto = new File("Directorio.txt");
            FileWriter output = new FileWriter(proyecto, true);
            for(int i=0; i<datos.size(); ++i){
                out.println(datos.get(i));
            }
            if(existe == false){
                out.println("|--["+usuario+" "+tam+"] "+directorio);
                agregarFichero(usuario, tam, directorio, fichero);
            }
        }
        catch(Exception e){
            System.out.println("Ha ocurrido un error");
        }
    }
    
    public void buscarFichero(String fichero){
        try{
            Scanner input = new Scanner(new File("Directorio.txt"));
            boolean existe = false;
            while(input.hasNext()){
                String line = input.nextLine();
                if(line.contains("|--[")){
                    while(input.hasNext()){
                        String[] array = line.split("] ");
                        String str = "";
                        String line2 = input.nextLine();
                        String [] array2 = line2.split("] ");
                        str = array2[1];
                        while(line2.contains("|--[")){
                            line = line2;
                            line2 = input.nextLine();
                            array2 = line2.split("] ");
                            str = array2[1];
                        }
                        if(str.equals(fichero)){
                            System.out.println("El fichero "+fichero+" Se encuentra en el directorio "+line);
                            existe = true;
                            break;
                        }
                    }
                }
                if(existe == true){
                    break;
                }
            }
            if(existe == false){
                    System.out.println("El fichero "+ fichero + " no existe");
                }
        }
        catch(Exception e){
            System.out.println("Ah ocurrido un error en la busqueda");
        }
    }
    
    public void borrarFichero(String fichero){
        try{
            Scanner input = new Scanner(new File("Directorio.txt"));
            ArrayList<String> datos = new ArrayList<String>();
            int cont = 0;
            boolean existe = false;
            while(input.hasNext()){
                String mod=input.nextLine();   
                if(!mod.contains(fichero)){
                    datos.add(mod); 
                }               
            }
            PrintStream out = new PrintStream(new File("Directorio.txt"));
            File proyecto = new File("Directorio.txt");
            FileWriter output = new FileWriter(proyecto, true);
            for(int i=0; i<datos.size(); ++i){
                out.println(datos.get(i));
            }
            System.out.println("Fichero eliminado");
        }
        catch(Exception e){
            System.out.println("Ha ocurrido un error");
        }
    }
    
    public static void main(String[] args){
        Proyecto pr = new Proyecto();
        Scanner scan = new Scanner(System.in);
        System.out.println("Proyecto Estructura de datos y algoritmos I");
        
        String res = "no";
        
        do{
            System.out.println("\nProyecto");
            System.out.println("1. Agregar directorio");
            System.out.println("2. Agregar fichero");
            System.out.println("3. Buscar fichero");
            System.out.println("4. Borrar fichero");
            System.out.println("5. Vaciar proyecto");
            System.out.println("6. Terminar");
            
            int elegir = scan.nextInt();
            switch(elegir){
                case 1:
                    System.out.println("Ingrese el usuario, tamaño, y nombre del directorio que desea añadir");
                    pr.agregarDirectorio(scan.next(), scan.next(), scan.next());
                    break;
                case 2:
                    System.out.println("Ingrese el usuario, tamaño, directorio y nombre del fichero que desea añadir");
                    pr.agregarFichero(scan.next(), scan.next(), scan.next(), scan.next());
                    break;
                case 3:
                    System.out.println("Ingrese el nombre del fichero que desea buscar");
                    pr.buscarFichero(scan.next());
                    break;
                case 4:
                    System.out.println("Ingrese el nombre del fichero que desea borrar");
                    pr.borrarFichero(scan.next());
                    break;
                case 5:
                    System.out.println("¿Seguro que desea vacíar el proyecto? (si o no)");
                    if(scan.next().equals("si")){
                        pr.vaciar();
                        break;
                    }
                    break;
                case 6:
                    System.out.println("¿Seguro que desea salir del proyecto? (si o no)");
                    res = scan.next();
                    break;
                default:
                    System.out.println("Entrada invalida");
                    break;
            }
        }
        while(!res.equals("si"));
    }
}