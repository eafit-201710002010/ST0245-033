
/**
 * Solución al ejercicio 1 del laboratorio 1, Estructuras de datos y algoritmos I
 * 
 * Código base: Mauricio Toro 
 * Mateo Florez Restrepo, Isabela Muriel Roldán
 * @version (a version number or a date)
 */

import java.util.Arrays;
import java.util.*;
import java.util.concurrent.TimeUnit;
public class EjerciciosGitHub
{    
    // Retorna la suma de los números dentro de un arreglo
    public static int ArraySum(int[] A, int n){          
        int sum;

        if(A.length==0)
            return sum=0;
        if (n == 0)
            sum = A[0];
        else 
            sum = A[n] + ArraySum(A,n-1);
        try{
            TimeUnit.SECONDS.sleep(1);
        }
        catch(Exception e){
            
        }
        return sum;
    }
  
    // Retorna el valor máximo dentro de un arreglo
    public static int ArrayMax(int[] A, int n){
        int max;
        if(A.length==0)
            return max=0;
        if (n == 0)
            max = A[0];
        else
            max = Math.max(A[n],ArrayMax(A, n-1));
        try{
            TimeUnit.SECONDS.sleep(1);
        }
        catch(Exception e){
            
        }
        return max;
    }
  
    // Retorna el numero fibonnacci del número ingresado
    public static int Fibonnacci(int n){ 
        int result;
        if (n == 0 || n == 1)
          result = n;
        else
            result = Fibonnacci(n-1) + Fibonnacci(n-2);
        try{
            TimeUnit.SECONDS.sleep(1);
        }
        catch(Exception e){
            
        }
        return result;
    }
    
    // Generar un arreglo de numeros aleatorios
    public static int[] generarArregloDeTamanoN(int n){
        int max = 5000;
        int[] array = new int[n];
        Random generator = new Random();
        for (int i =0; i<n; i++)
            array[i] = generator.nextInt(max);
        System.out.println(Arrays.toString(array));
        return array;
    }
    
    // Tomar el tiempo que toma la ejecución de los métodos arraySum(), arrayMax() y fibonnacci()
    public static long tomarTiempo(int n){
        int[]a = generarArregloDeTamanoN(n);
        long startTime = System.currentTimeMillis();
        long estimatedTime1 = System.currentTimeMillis()-startTime;
        System.out.println("ArraySum: "+ArraySum(a, a.length-1)+" Tiempo: "+estimatedTime1);
        long estimatedTime2 = System.currentTimeMillis()-startTime;
        System.out.println("ArrayMax: "+ArrayMax(a, a.length-1)+" Tiempo: "+estimatedTime2);
        long estimatedTime3 = System.currentTimeMillis()-startTime;
        System.out.println("Fibonnacci: "+Fibonnacci(a.length)+" Tiempo: "+estimatedTime3);
        long estimatedTime = System.currentTimeMillis()-startTime;
        return estimatedTime;
    }
    
    public static void main(String[] args){
        System.out.println(tomarTiempo(10));
    } 
}

